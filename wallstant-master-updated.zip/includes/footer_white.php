<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
<div class="footer_white" style="margin:0px 15%;padding: 15px; color: #fff; text-align: center;border-top: 1px solid #1f648e;">
    Wallstant &copy; All rights reserved.
</div>